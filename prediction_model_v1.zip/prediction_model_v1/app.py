import os
from flask import Flask, request, render_template, redirect, url_for, flash, jsonify
from werkzeug.utils import secure_filename
from PIL import Image
import torch
import torchvision.transforms as transforms
import uuid
from model_eval import load_best_model, get_all_experiments

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'your-secret-key-here')
UPLOAD_FOLDER = "static/uploads"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg"}

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Define transform same as training pipeline
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor()
])

# Global variables for current model state
current_model = None
current_class_names = []
current_experiment = None
current_run_id = None
current_accuracy = None

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_default_experiment(experiments):
    """Get default experiment with fallback handling"""
    if not experiments:
        return None
    return experiments[0]

@app.route('/')
def index():
    global current_model, current_class_names, current_experiment, current_run_id, current_accuracy
    
    experiments = get_all_experiments()
    selected_experiment = request.args.get('experiment')
    
    # If no experiment selected, use default (first available)
    if not selected_experiment:
        selected_experiment = get_default_experiment(experiments)
        if not selected_experiment:
            flash("No experiments available. Please train a model first.", 'danger')
            return render_template('index.html', experiments=[], selected_experiment=None)
    
    # If experiment changed or no model loaded yet
    if selected_experiment != current_experiment or current_model is None:
        loaded_model, run_id, val_accuracy, class_names, error = load_best_model(selected_experiment)
        
        if error:
            flash(error, 'warning')
            # Try to fall back to default experiment
            default_exp = get_default_experiment(experiments)
            if default_exp and selected_experiment != default_exp:
                return redirect(url_for('index', experiment=default_exp))
            return render_template('index.html', 
                                 experiments=experiments,
                                 selected_experiment=selected_experiment,
                                 run_id=None,
                                 accuracy="N/A")
        
        current_model = loaded_model
        current_class_names = class_names or [f"Class {i}" for i in range(5)]  # Generic fallback
        current_experiment = selected_experiment
        current_run_id = run_id
        current_accuracy = val_accuracy

    return render_template(
        'index.html',
        experiments=experiments,
        selected_experiment=current_experiment,
        run_id=current_run_id,
        accuracy=round(current_accuracy * 100, 2) if current_accuracy else "N/A",
        class_names=current_class_names
    )

@app.route('/select_experiment', methods=['POST'])
def select_experiment():
    selected_experiment = request.form['experiment']
    return redirect(url_for('index', experiment=selected_experiment))
# @app.route('/predict', methods=['POST'])
@app.route('/predict', methods=['POST'])
def predict():
    global current_model, current_class_names
    
    print("\n=== Starting Prediction ===")
    print(f"Current class names: {current_class_names}")
    print(f"Type of current_class_names: {type(current_class_names)}")
    
    if current_model is None:
        flash("No valid model is currently loaded.", 'danger')
        return redirect(url_for('index'))
    
    if not current_class_names:
        flash("No class names available for the current model.", 'danger')
        return redirect(url_for('index'))
    
    predictions = []
    files = request.files.getlist('images')

    for file in files:
        if file and allowed_file(file.filename):
            try:
                filename = secure_filename(f"{uuid.uuid4().hex}_{file.filename}")
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)

                image = Image.open(filepath).convert('RGB')
                input_tensor = transform(image).unsqueeze(0)

                with torch.no_grad():
                    outputs = current_model(input_tensor)
                    probs = torch.nn.functional.softmax(outputs[0], dim=0)
                    conf, predicted_class = torch.max(probs, 0)
                    class_idx = predicted_class.item()
                    
                    print(f"\nPrediction for {filename}:")
                    print(f"Raw model output: {outputs}")
                    print(f"Predicted class index: {class_idx}")
                    print(f"Available classes: {current_class_names}")
                    
                    try:
                        class_name = current_class_names[class_idx]
                        print(f"Matched class name: {class_name}")
                    except IndexError:
                        class_name = f"Class {class_idx}"
                        print(f"Index out of range! Using fallback name: {class_name}")
                        flash(f"Model predicted class index {class_idx} which is out of bounds", 'warning')

                predictions.append({
                    'filename': filename,
                    'class': class_name,
                    'confidence': round(conf.item() * 100, 2)
                })
                
            except Exception as e:
                print(f"Error processing {file.filename}: {e}")
                flash(f"Error processing {file.filename}", 'danger')
                continue
    
    print("\n=== Prediction Complete ===")
    print(f"Predictions: {predictions}")
    return render_template('index.html', 
                         predictions=predictions,
                         experiments=get_all_experiments(),
                         selected_experiment=current_experiment,
                         run_id=current_run_id,
                         accuracy=round(current_accuracy * 100, 2) if current_accuracy else "N/A",
                         class_names=current_class_names)

if __name__ == '__main__':
    app.run(debug=True, port=5001)