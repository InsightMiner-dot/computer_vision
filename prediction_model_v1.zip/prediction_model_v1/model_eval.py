import mlflow
import mlflow.pytorch
from mlflow.exceptions import MlflowException
from mlflow.tracking import MlflowClient

def get_all_experiments():
    client = MlflowClient()
    experiments = client.search_experiments()
    return [exp.name for exp in experiments if exp.name != "Default"]

def load_best_model(experiment_name="Flower_Classification_Experiment"):
    try:
        print(f"\n=== Loading model for experiment: {experiment_name} ===")
        mlflow.set_experiment(experiment_name)
        client = MlflowClient()
        experiment = client.get_experiment_by_name(experiment_name)
        
        if experiment is None:
            print(f"Experiment '{experiment_name}' not found")
            return None, None, None, None, f"Experiment '{experiment_name}' not found"
        
        runs = client.search_runs(
            experiment.experiment_id,
            order_by=["metrics.val_accuracy DESC"]
        )
        print(f"Found {len(runs)} runs for this experiment")

        for i, run in enumerate(runs):
            run_id = run.info.run_id
            print(f"\nEvaluating run {i+1}/{len(runs)} - Run ID: {run_id}")
            
            try:
                # Print all parameters for debugging
                print("Run Parameters:")
                for key, value in run.data.params.items():
                    print(f"  {key}: {value} (type: {type(value)})")
                
                # Get class names with detailed debugging
                class_names = run.data.params.get("class_names", None)
                print(f"Raw class_names from params: {class_names} (type: {type(class_names)})")
                
                # Handle different storage formats
                if class_names is not None:
                    if isinstance(class_names, str):
                        print("Class names is a string, attempting to parse...")
                        try:
                            # First try to evaluate as a Python literal (if stored as list string)
                            try:
                                import ast
                                class_names = ast.literal_eval(class_names)
                                print(f"Evaluated class_names: {class_names} (type: {type(class_names)})")
                            except:
                                # If that fails, try splitting by comma
                                class_names = [name.strip() for name in class_names.split(',')]
                                print(f"Split class_names: {class_names} (type: {type(class_names)})")
                        except Exception as e:
                            print(f"Failed to parse class_names string: {e}")
                            class_names = None
                    
                    if not isinstance(class_names, list):
                        print("Class names is not a list, setting to None")
                        class_names = None
                
                print(f"Final class_names to use: {class_names}")
                
                model = mlflow.pytorch.load_model(f"runs:/{run_id}/model")
                best_run_id = run_id
                best_val_accuracy = run.data.metrics.get("val_accuracy", None)
                
                model.eval()
                return model, best_run_id, best_val_accuracy, class_names, None
                
            except Exception as e:
                print(f"Skipping run {run_id}: {e}")
                continue

        return None, None, None, None, f"No valid model found in experiment '{experiment_name}'"
    except Exception as e:
        print(f"Error in load_best_model: {str(e)}")
        return None, None, None, None, f"Error loading model: {str(e)}"

    model.eval()
    return model, best_run_id, best_val_accuracy